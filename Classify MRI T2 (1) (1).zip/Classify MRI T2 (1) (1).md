##### Copyright 2018 The TensorFlow Authors.


```python
#@title Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
```


```python
# pip install tensorflow==2.10.0.*
```


```python
# import shutil
# os.remove("./train.zip")
# shutil.rmtree("./train")
```

# Image classification


```python
# pip list
```

<table class="tfo-notebook-buttons" align="left">
  <td>
    <a target="_blank" href="https://www.tensorflow.org/tutorials/images/classification"><img src="https://www.tensorflow.org/images/tf_logo_32px.png" />View on TensorFlow.org</a>
  </td>
  <td>
    <a target="_blank" href="https://colab.research.google.com/github/tensorflow/docs/blob/master/site/en/tutorials/images/classification.ipynb"><img src="https://www.tensorflow.org/images/colab_logo_32px.png" />Run in Google Colab</a>
  </td>
  <td>
    <a target="_blank" href="https://github.com/tensorflow/docs/blob/master/site/en/tutorials/images/classification.ipynb"><img src="https://www.tensorflow.org/images/GitHub-Mark-32px.png" />View source on GitHub</a>
  </td>
  <td>
    <a href="https://storage.googleapis.com/tensorflow_docs/docs/site/en/tutorials/images/classification.ipynb"><img src="https://www.tensorflow.org/images/download_logo_32px.png" />Download notebook</a>
  </td>
</table>

This tutorial shows how to classify images of flowers using a `tf.keras.Sequential` model and load data using `tf.keras.utils.image_dataset_from_directory`. It demonstrates the following concepts:


* Efficiently loading a dataset off disk.
* Identifying overfitting and applying techniques to mitigate it, including data augmentation and dropout.

This tutorial follows a basic machine learning workflow:

1. Examine and understand data
2. Build an input pipeline
3. Build the model
4. Train the model
5. Test the model
6. Improve the model and repeat the process

In addition, the notebook demonstrates how to convert a [saved model](../../../guide/saved_model.ipynb) to a [TensorFlow Lite](https://www.tensorflow.org/lite/) model for on-device machine learning on mobile, embedded, and IoT devices.

## Setup

Import TensorFlow and other necessary libraries:


```python
import matplotlib.pyplot as plt
import numpy as np
import PIL
import tensorflow as tf
import os
import boto3
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers.legacy import Adam
```


```python
tf.version.VERSION
```




    '2.12.0'




```python
# # import boto3
# # # import awswrangler as wr

# # # Define your AWS access key and secret key
# aws_access_key_id = "AKIASNSREPJV4LF3IK4V"
# aws_secret_access_key = "KyWYxxbcekLFIbz59jwdxYaXByKZcu4sGWYqmQgF"

# # # Use boto3 to create a session with your AWS credentials
# session = boto3.Session(
#      aws_access_key_id=aws_access_key_id,
#      aws_secret_access_key=aws_secret_access_key
#  )

# # # Use awswrangler to connect to your S3 bucket
# # bucket_name = "classifyraw"
# # subfolder = "MRI_T2"

# # # List the contents of your S3 bucket
# # s3 = session.resource("s3")
# # result = s3.Bucket(bucket_name)

# # for my_bucket_object in result.objects.filter(Prefix="modeling_mri_t2/train/"):
# #     print(my_bucket_object.key)

# # # Print the contents of the bucket
# # # if "Contents" in result:
# # #     for obj in result["Contents"]:
# # #         print(obj)
# # # else:
# # #     print("The bucket is empty.")


# import boto3
# from os import path, makedirs
# from botocore.exceptions import ClientError
# from boto3.exceptions import S3TransferFailedError

```


```python
# import zipfile
# with zipfile.ZipFile("./train.zip", 'r') as zip_ref:
#     zip_ref.extractall("./")
```

## Download and explore the dataset


```python
import pathlib

data_dir =  "/Users/SeanKelly1/Documents/FinalThesis(2023Ulster)/Raw/All/modeling_mri_t2/train/"

data_dir = '/home/ec2-user/SageMaker/train'
data_dir = pathlib.Path(data_dir)
```


```python
import os
print(len(os.listdir(data_dir)))
```

    3



```python
len(list(data_dir.glob('demented/*.jpg')))
```




    11502



After downloading, you should now have a copy of the dataset available. There are 3,670 total images:


```python
image_count = len(list(data_dir.glob('*/*.jpg')))
print(image_count)
```

    23003


Resize all the images


```python
# from matplotlib import image as im
# import random
# all_images = list(data_dir.glob('*/*.jpg'))
# print(len(all_images))


# for each in all_images:
# #     name = str(each).split("/")[9]
# #     first = name.split(".")[0]
# #     second = name.split(".")[1]
#     each = pathlib.Path(str(each))
# #     print(each)
# #     ima = im.imread('/home/ec2-user/SageMaker/train/not_demented/OAS31081_02_0.0_29.jpg')
#     image = PIL.Image.open(each)
#     image = PIL.ImageOps.grayscale(image)
# #     image = image.convert("RGB")
#     image = image.resize((224, 224))
#     image.save(str(each))
#     print("done")
    

# random_list = random.sample(range(0, 11503), demented_size)
# for temp in random_list:
#     each = not_demented[temp]
#     name = str(each).split("/")[9]
#     first = name.split(".")[0]
#     second = name.split(".")[1]
#     rename = f"/Users/SeanKelly1/Documents/FinalThesis(2023Ulster)/Raw/All/PIB/train/not_demented/{first}.{second}.jpg"
#     image = PIL.Image.open(str(each))
#     image = image.convert("RGB")
#     image = image.resize((126, 126))
#     image.save(rename)
#     print("done not demented")




```


```python
# Imports PIL module 
from PIL import Image
  
# open method used to open different extension image file
im = Image.open(r"/home/ec2-user/SageMaker/train/not_demented/OAS30335_TSE_0.0_32.jpg") 
  
# This method will show image in any image viewer 
im.size
```




    (128, 128)



Here are some demented:


```python
demented = list(data_dir.glob('demented/*'))
img = PIL.Image.open(str(demented[0]))
print(img.size)
```

    (128, 128)



```python
PIL.Image.open(str(demented[2]))
```




    
![png](output_24_0.png)
    



And some non_demented:


```python
not_demented = list(data_dir.glob('not_demented/*'))
PIL.Image.open(str(not_demented[0]))
```




    
![png](output_26_0.png)
    




```python
PIL.Image.open(str(not_demented[1]))
```




    
![png](output_27_0.png)
    



Create the test set from the full data


```python
# # Create the test folder
# # From each class select random 10% of the total

# test_dem = "/Users/SeanKelly1/Documents/FinalThesis(2023Ulster)/Raw/All/modeling_mri_t2/test/demented"
# test_not_dem = "/Users/SeanKelly1/Documents/FinalThesis(2023Ulster)/Raw/All/modeling_mri_t2/test/not_demented"
 

# if os.path.exists(test_dem) or os.path.exists(test_not_dem):
#     print("above folders exists")
# else:
#     os.makedirs(test_dem)
#     os.makedirs(test_not_dem)
#     print("created")

```


```python
print(data_dir)
```

    /home/ec2-user/SageMaker/train



```python
# import random

# random_list = []
# # Set a length of the list to 10

# # any random numbers from 0 to 1000
# random_list = random.sample(range(0, 12781), 1278)
# demented = list(data_dir.glob('demented/*'))
# not_demented = list(data_dir.glob('not_demented/*'))
# # print(len(demented))
# # print(len(not_demented))
# for each in random_list:
#     demented_test_filename = str(demented[each]).split("/")[9]
#     not_demented_test_filename = str(not_demented[each]).split("/")[9]
#     os.replace(demented[each], test_dem + "/" + demented_test_filename)
#     os.replace(not_demented[each], test_not_dem + "/" + not_demented_test_filename)

# print("done")
```

## Load data using a Keras utility

Next, load these images off disk using the helpful `tf.keras.utils.image_dataset_from_directory` utility. This will take you from a directory of images on disk to a `tf.data.Dataset` in just a couple lines of code. If you like, you can also write your own data loading code from scratch by visiting the [Load and preprocess images](../load_data/images.ipynb) tutorial.

### Create a dataset

Define some parameters for the loader:


```python
batch_size = 32
img_height = 128
img_width = 128
```

We split the data into train and validation in proportion of 4:1


```python
train_ds = tf.keras.utils.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,
  subset="training",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size, 
    color_mode = "rgb",
label_mode = "int")
```

    Found 23003 files belonging to 2 classes.
    Using 18403 files for training.



```python
val_ds = tf.keras.utils.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,
  subset="validation",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size,
color_mode = "rgb",
label_mode = "int")
```

    Found 23003 files belonging to 2 classes.
    Using 4600 files for validation.


You can find the class names in the `class_names` attribute on these datasets. These correspond to the directory names in alphabetical order.


```python
class_names = train_ds.class_names
print(class_names)
```

    ['demented', 'not_demented']


## Visualize the data

Here are the first nine images from the training dataset:


```python
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 10))
for images, labels in train_ds.take(1):
    print(labels)
    for i in range(9):
        ax = plt.subplot(3, 3, i + 1)
        plt.imshow(images[i].numpy().astype("uint8"))
        plt.title(class_names[labels[i]])
        plt.axis("off")
```

    tf.Tensor([1 1 0 1 0 0 1 1 1 0 1 0 1 1 1 0 0 1 1 1 0 0 0 1 1 0 0 1 0 1 0 1], shape=(32,), dtype=int32)



    
![png](output_42_1.png)
    


You will pass these datasets to the Keras `Model.fit` method for training later in this tutorial. If you like, you can also manually iterate over the dataset and retrieve batches of images:


```python
for image_batch, labels_batch in train_ds:
  print(image_batch.shape)
  print(labels_batch.shape)
  break
```

    (32, 128, 128, 3)
    (32,)


The `image_batch` is a tensor of the shape `(32, 128, 128, 3)`. This is a batch of 32 images of shape `126x126x3` (the last dimension refers to color channels RGB). The `label_batch` is a tensor of the shape `(32,)`, these are corresponding labels to the 32 images.

You can call `.numpy()` on the `image_batch` and `labels_batch` tensors to convert them to a `numpy.ndarray`.


## Configure the dataset for performance

Make sure to use buffered prefetching, so you can yield data from disk without having I/O become blocking. These are two important methods you should use when loading data:

- `Dataset.cache` keeps the images in memory after they're loaded off disk during the first epoch. This will ensure the dataset does not become a bottleneck while training your model. If your dataset is too large to fit into memory, you can also use this method to create a performant on-disk cache.
- `Dataset.prefetch` overlaps data preprocessing and model execution while training.

Interested readers can learn more about both methods, as well as how to cache data to disk in the *Prefetching* section of the [Better performance with the tf.data API](../../guide/data_performance.ipynb) guide.


```python
AUTOTUNE = tf.data.AUTOTUNE

train_ds = train_ds.cache().shuffle(1000).prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)
```

## Standardize the data

The RGB channel values are in the `[0, 255]` range. This is not ideal for a neural network; in general you should seek to make your input values small.

Here, you will standardize values to be in the `[0, 1]` range by using `tf.keras.layers.Rescaling`:


```python
normalization_layer = layers.Rescaling(1./255)
```

There are two ways to use this layer. You can apply it to the dataset by calling `Dataset.map`:


```python
normalized_ds = train_ds.map(lambda x, y: (normalization_layer(x), y))
image_batch, labels_batch = next(iter(normalized_ds))
first_image = image_batch[0]
# Notice the pixel values are now in `[0,1]`.
print(np.min(first_image), np.max(first_image))
```

    0.0 0.9803922


Or, you can include the layer inside your model definition, which can simplify deployment. Use the second approach here.

Note: You previously resized images using the `image_size` argument of `tf.keras.utils.image_dataset_from_directory`. If you want to include the resizing logic in your model as well, you can use the `tf.keras.layers.Resizing` layer.

##  RANDOM FOREST MODEL

### Create and Train the model




```python
from sklearn.ensemble import RandomForestClassifier




# Generate Test data 
import pathlib

train_dir = "/home/ec2-user/SageMaker/train"

print(os.listdir(train_dir))

demented = "/home/ec2-user/SageMaker/train/demented"
not_demented = "/home/ec2-user/SageMaker/train/not_demented"

print(len(os.listdir(demented)))


demented_data = os.listdir(demented)
not_demented_data = os.listdir(not_demented)

train_data = []
train_labels = []
for i in range(len(os.listdir(demented))):
    try:
        temp_file_d = demented_data[i]
        path = demented + "/" + temp_file_d
        temp = pathlib.Path(path)
        image_dem = tf.keras.utils.load_img(temp)
        train_data.append(image_dem)
        train_labels.append("demented")
#         print(image_dem)
#         print(list(zip(data, labels)))

        
        temp_file_nd = not_demented_data[i]
        path_temp = not_demented + "/" + temp_file_nd
        tempn = pathlib.Path(path_temp)
        image_ndem = tf.keras.utils.load_img(tempn)
        train_data.append(image_ndem)
        train_labels.append("not_demented")
    except Exception as err :
        print(i, err)
        continue
print(len(train_data), len(train_labels))

```

    ['not_demented', '.DS_Store', 'demented']
    11503
    5155 cannot identify image file <_io.BytesIO object at 0x7fa4a7f20b30>
    5166 cannot identify image file <_io.BytesIO object at 0x7fa4a7fb5d00>
    11502 list index out of range
    23002 23002



```python
previous_train_img1 = tf.expand_dims(train_data[0], 0) # Create a batch

for i in range(1, 2000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img1 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img1 = np.concatenate((current_train_img1, previous_train_img1), axis=0)
#         print(i)
print(previous_train_img1.shape)

```


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    Cell In[40], line 9
          7     else:
          8         current_train_img1 = tf.expand_dims(train_data[i], 0) # Create a batch
    ----> 9         previous_train_img1 = np.concatenate((current_train_img1, previous_train_img1), axis=0)
         10 #         print(i)
         11 print(previous_train_img1.shape)


    File <__array_function__ internals>:200, in concatenate(*args, **kwargs)


    KeyboardInterrupt: 



```python
previous_train_img2 = tf.expand_dims(train_data[2000], 0) # Create a batch

for i in range(2001, 4000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img2 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img2 = np.concatenate((current_train_img2, previous_train_img2), axis=0)
#         print(i)
print(previous_train_img2.shape)

```


```python
previous_train_img3 = tf.expand_dims(train_data[4000], 0) # Create a batch

for i in range(4001, 6000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img3 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img3 = np.concatenate((current_train_img3, previous_train_img3), axis=0)
#         print(i)
print(previous_train_img3.shape)

```


```python
previous_train_img4 = tf.expand_dims(train_data[6000], 0) # Create a batch

for i in range(6001, 8000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img4 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img4 = np.concatenate((current_train_img4, previous_train_img4), axis=0)
#         print(i)
print(previous_train_img4.shape)
```


```python
previous_train_img5 = tf.expand_dims(train_data[8000], 0) # Create a batch

for i in range(8001, 10000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img5 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img5 = np.concatenate((current_train_img5, previous_train_img5), axis=0)
#         print(i)
print(previous_train_img5.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img6 = tf.expand_dims(train_data[10000], 0) # Create a batch

for i in range(10001, 12000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img6 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img6 = np.concatenate((current_train_img6, previous_train_img6), axis=0)
#         print(i)
print(previous_train_img6.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img7 = tf.expand_dims(train_data[12000], 0) # Create a batch

for i in range(12001, 14000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img7 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img7 = np.concatenate((current_train_img7, previous_train_img7), axis=0)
#         print(i)
print(previous_train_img7.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img8 = tf.expand_dims(train_data[14000], 0) # Create a batch

for i in range(14001, 16000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img8 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img8 = np.concatenate((current_train_img8, previous_train_img8), axis=0)
#         print(i)
print(previous_train_img8.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img9 = tf.expand_dims(train_data[16000], 0) # Create a batch

for i in range(16001, 18000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img9 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img9 = np.concatenate((current_train_img9, previous_train_img9), axis=0)
#         print(i)
print(previous_train_img9.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img10 = tf.expand_dims(train_data[18000], 0) # Create a batch

for i in range(18001, 20000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img10 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img10 = np.concatenate((current_train_img10, previous_train_img10), axis=0)
#         print(i)
print(previous_train_img10.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img11 = tf.expand_dims(train_data[20000], 0) # Create a batch

for i in range(20001, 22000):
    if (i == 23001):
        print("end of loop")
        break
    else:
        current_train_img11 = tf.expand_dims(train_data[i], 0) # Create a batch
        previous_train_img11 = np.concatenate((current_train_img11, previous_train_img11), axis=0)
#         print(i)
print(previous_train_img11.shape)
```

    (2000, 128, 128, 3)



```python
previous_train_img12 = tf.expand_dims(train_data[22000], 0) # Create a batch

for i in range(22001, 23002):
    current_train_img12 = tf.expand_dims(train_data[i], 0) # Create a batch
    previous_train_img12 = np.concatenate((current_train_img12, previous_train_img12), axis=0)
#         print(i)
print(previous_train_img12.shape)
```

    (1002, 128, 128, 3)



```python
res1 = np.concatenate((previous_train_img1, previous_train_img2), axis=0)
res2 = np.concatenate((previous_train_img3, previous_train_img4), axis=0)
res3 = np.concatenate((previous_train_img5, previous_train_img6), axis=0)
res4 = np.concatenate((previous_train_img7, previous_train_img8), axis=0)
res5 = np.concatenate((previous_train_img9, previous_train_img10), axis=0)
res6 = np.concatenate((previous_train_img11, previous_train_img12), axis=0)
gen1 = np.concatenate((res1, res2), axis=0)
gen2 = np.concatenate((res3, res4), axis=0)
gen3 = np.concatenate((res5, res6), axis=0)
nex = np.concatenate((gen1, gen2), axis=0)
ans = np.concatenate((nex, gen3), axis=0)

print(ans.shape)
print(len(train_labels))

```

    (23002, 128, 128, 3)
    23002



```python
from sklearn.ensemble import RandomForestClassifier


train_d = ans
fir, sec, third, fourth = train_d.shape
print(sec, third, fourth)
train_d_r = train_d.reshape(fir, (sec*third*fourth))

print(train_d_r.shape)


# Create an instance of the RandomForestClassifier class:

model=RandomForestClassifier()

# Finally, let us proceed to train the model:

model.fit(train_d_r, train_labels)






```

    128 128 3
    (23002, 49152)





<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">RandomForestClassifier</label><div class="sk-toggleable__content"><pre>RandomForestClassifier()</pre></div></div></div></div></div>




```python
# Generate Test data 
import pathlib

test_dir = "/home/ec2-user/SageMaker/test"

print(os.listdir(test_dir))

demented = "/home/ec2-user/SageMaker/test/demented"
not_demented = "/home/ec2-user/SageMaker/test/not_demented"

print(len(os.listdir(demented)))


demented_data = os.listdir(demented)
not_demented_data = os.listdir(not_demented)

data = []
labels = []
for i in range(len(os.listdir(demented))):
    try:
        temp_file_d = demented_data[i]
        path = demented + "/" + temp_file_d
        temp = pathlib.Path(path)
        image_dem = tf.keras.utils.load_img(temp)
        data.append(image_dem)
        labels.append("demented")
#         print(image_dem)
#         print(list(zip(data, labels)))

        
        temp_file_nd = not_demented_data[i]
        path_temp = not_demented + "/" + temp_file_nd
        tempn = pathlib.Path(path_temp)
        image_ndem = tf.keras.utils.load_img(tempn)
        data.append(image_ndem)
        labels.append("not_demented")
    except:
        print(i)
        continue
print(len(data), len(labels))
```


```python
previous_img = tf.expand_dims(data[0], 0) # Create a batch

for i in range(1, 2553):
    current_img = tf.expand_dims(data[i], 0) # Create a batch
    previous_img = np.concatenate((current_img, previous_img), axis=0)

# print(previous_img.shape)
f, s, t, fo = previous_img.shape

prev_img = previous_img.reshape(f, (s*t*fo))

print(prev_img.shape)


lab = []
for each in labels:
    if each == "demented":
        lab.append(0)
    elif each == "not_demented":
        lab.append(1)
print(len(lab))

```


```python
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report


predictions = model.predict(prev_img)
# score = tf.nn.softmax(predictions)
# class_index = [np.argmax(x) for x in score]
# class_name = [class_names[index] for index in class_index]


y_pred = predictions
y_test = lab
# print(len(class_name))
# print(class_name[455])

# classification_report = classification_report(y_pred, y_test)
# confusion_matrix = confusion_matrix(y_pred, y_test)
# print(confusion_matrix)



# print(
#     "This image most likely belongs to {} with a {:.2f} percent confidence."
#     .format(class_names[np.argmax(score)], 100 * np.max(score))
# )



import pandas as pd

print(type(predictions))

pd.Index(list(predictions[0:1276])).value_counts()
```

### CNN model

Train the model for 10 epochs with the Keras `Model.fit` method:

Overfitting generally occurs when there are a small number of training examples. [Data augmentation](./data_augmentation.ipynb) takes the approach of generating additional training data from your existing examples by augmenting them using random transformations that yield believable-looking images. This helps expose the model to more aspects of the data and generalize better.

You will implement data augmentation using the following Keras preprocessing layers: `tf.keras.layers.RandomFlip`, `tf.keras.layers.RandomRotation`, and `tf.keras.layers.RandomZoom`. These can be included inside your model like other layers, and run on the GPU.


```python
data_augmentation = keras.Sequential(
  [
    layers.RandomFlip("horizontal",
                      input_shape=(img_height,
                                  img_width,
                                  3)),
    layers.RandomRotation(0.7),
    layers.RandomZoom(0.005),
    layers.Resizing(224, 224),
    layers.RandomFlip( mode="horizontal_and_vertical")
  ]
)
```

Visualize a few augmented examples by applying data augmentation to the same image several times:


```python
plt.figure(figsize=(10, 10))
for images, _ in train_ds.take(1):
  for i in range(9):
    augmented_images = data_augmentation(images)
    ax = plt.subplot(3, 3, i + 1)
    plt.imshow(augmented_images[0].numpy().astype("uint8"))
    plt.axis("off")
```


    
![png](output_79_0.png)
    


You will add data augmentation to your model before training in the next step.

## Dropout

Another technique to reduce overfitting is to introduce [dropout](https://developers.google.com/machine-learning/glossary#dropout_regularization){:.external} regularization to the network.

When you apply dropout to a layer, it randomly drops out (by setting the activation to zero) a number of output units from the layer during the training process. Dropout takes a fractional number as its input value, in the form such as 0.1, 0.2, 0.4, etc. This means dropping out 10%, 20% or 40% of the output units randomly from the applied layer.

Create a new neural network with `tf.keras.layers.Dropout` before training it using the augmented images:


```python
num_classes = len(class_names)

model = Sequential([
  data_augmentation,
  layers.Rescaling(1./255, input_shape=(img_height, img_width, 3)),
  layers.Conv2D(16, 3, padding='valid', activation='relu', data_format= "channels_last"),
  layers.MaxPooling2D(data_format= "channels_last"),
  layers.Conv2D(32, 3, padding='valid', activation='relu', data_format= "channels_last"),
  layers.MaxPooling2D(data_format= "channels_last"),
  layers.Conv2D(64, 3, padding='valid', activation='relu', data_format= "channels_last"),
  layers.MaxPooling2D(data_format= "channels_last"),
  layers.Conv2D(128, 3, padding='valid', activation='relu', data_format= "channels_last"),
  layers.MaxPooling2D(data_format= "channels_last"),
#   layers.Dropout(0.0),
  layers.Flatten(),
  layers.Dense(128, activation='relu', kernel_regularizer='l2'),
  layers.Dense(64, activation='relu', kernel_regularizer='l2'),
  layers.Dense(num_classes, name="outputs")
])

model.compile(optimizer='adam',
              loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

model.summary()
```

    Model: "sequential_1"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     sequential (Sequential)     (None, 224, 224, 3)       0         
                                                                     
     rescaling_1 (Rescaling)     (None, 224, 224, 3)       0         
                                                                     
     conv2d (Conv2D)             (None, 222, 222, 16)      448       
                                                                     
     max_pooling2d (MaxPooling2D  (None, 111, 111, 16)     0         
     )                                                               
                                                                     
     conv2d_1 (Conv2D)           (None, 109, 109, 32)      4640      
                                                                     
     max_pooling2d_1 (MaxPooling  (None, 54, 54, 32)       0         
     2D)                                                             
                                                                     
     conv2d_2 (Conv2D)           (None, 52, 52, 64)        18496     
                                                                     
     max_pooling2d_2 (MaxPooling  (None, 26, 26, 64)       0         
     2D)                                                             
                                                                     
     conv2d_3 (Conv2D)           (None, 24, 24, 128)       73856     
                                                                     
     max_pooling2d_3 (MaxPooling  (None, 12, 12, 128)      0         
     2D)                                                             
                                                                     
     flatten (Flatten)           (None, 18432)             0         
                                                                     
     dense (Dense)               (None, 128)               2359424   
                                                                     
     dense_1 (Dense)             (None, 64)                8256      
                                                                     
     outputs (Dense)             (None, 2)                 130       
                                                                     
    =================================================================
    Total params: 2,465,250
    Trainable params: 2,465,250
    Non-trainable params: 0
    _________________________________________________________________


## Compile and train the model


```python
epochs = 150
history = model.fit(
  train_ds,
  validation_data=val_ds,
  epochs=epochs
)
```

    Epoch 1/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6093 - accuracy: 0.6736 - val_loss: 0.6172 - val_accuracy: 0.6680
    Epoch 2/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6073 - accuracy: 0.6778 - val_loss: 0.6208 - val_accuracy: 0.6596
    Epoch 3/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6077 - accuracy: 0.6764 - val_loss: 0.6233 - val_accuracy: 0.6698
    Epoch 4/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6059 - accuracy: 0.6804 - val_loss: 0.6330 - val_accuracy: 0.6620
    Epoch 5/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6052 - accuracy: 0.6805 - val_loss: 0.6173 - val_accuracy: 0.6672
    Epoch 6/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6072 - accuracy: 0.6762 - val_loss: 0.6205 - val_accuracy: 0.6611
    Epoch 7/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6086 - accuracy: 0.6784 - val_loss: 0.6192 - val_accuracy: 0.6767
    Epoch 8/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6092 - accuracy: 0.6743 - val_loss: 0.6163 - val_accuracy: 0.6704
    Epoch 9/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.6079 - accuracy: 0.6799 - val_loss: 0.6192 - val_accuracy: 0.6693
    Epoch 10/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6048 - accuracy: 0.6772 - val_loss: 0.6244 - val_accuracy: 0.6630
    Epoch 11/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6040 - accuracy: 0.6806 - val_loss: 0.6144 - val_accuracy: 0.6715
    Epoch 12/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6044 - accuracy: 0.6787 - val_loss: 0.6091 - val_accuracy: 0.6802
    Epoch 13/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6069 - accuracy: 0.6781 - val_loss: 0.6158 - val_accuracy: 0.6711
    Epoch 14/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6032 - accuracy: 0.6793 - val_loss: 0.6199 - val_accuracy: 0.6641
    Epoch 15/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6052 - accuracy: 0.6780 - val_loss: 0.6178 - val_accuracy: 0.6685
    Epoch 16/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6033 - accuracy: 0.6822 - val_loss: 0.6208 - val_accuracy: 0.6700
    Epoch 17/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6036 - accuracy: 0.6830 - val_loss: 0.6191 - val_accuracy: 0.6698
    Epoch 18/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6059 - accuracy: 0.6794 - val_loss: 0.6252 - val_accuracy: 0.6541
    Epoch 19/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6025 - accuracy: 0.6819 - val_loss: 0.6336 - val_accuracy: 0.6533
    Epoch 20/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6031 - accuracy: 0.6770 - val_loss: 0.6313 - val_accuracy: 0.6478
    Epoch 21/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6049 - accuracy: 0.6801 - val_loss: 0.6265 - val_accuracy: 0.6550
    Epoch 22/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6034 - accuracy: 0.6825 - val_loss: 0.6141 - val_accuracy: 0.6693
    Epoch 23/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6028 - accuracy: 0.6810 - val_loss: 0.6100 - val_accuracy: 0.6776
    Epoch 24/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6017 - accuracy: 0.6817 - val_loss: 0.6029 - val_accuracy: 0.6822
    Epoch 25/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6006 - accuracy: 0.6827 - val_loss: 0.6092 - val_accuracy: 0.6796
    Epoch 26/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6023 - accuracy: 0.6848 - val_loss: 0.6086 - val_accuracy: 0.6809
    Epoch 27/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6004 - accuracy: 0.6846 - val_loss: 0.6077 - val_accuracy: 0.6767
    Epoch 28/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6014 - accuracy: 0.6828 - val_loss: 0.6151 - val_accuracy: 0.6796
    Epoch 29/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5998 - accuracy: 0.6821 - val_loss: 0.6254 - val_accuracy: 0.6628
    Epoch 30/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6035 - accuracy: 0.6801 - val_loss: 0.6068 - val_accuracy: 0.6778
    Epoch 31/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6002 - accuracy: 0.6840 - val_loss: 0.6096 - val_accuracy: 0.6741
    Epoch 32/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5999 - accuracy: 0.6829 - val_loss: 0.6082 - val_accuracy: 0.6685
    Epoch 33/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.6021 - accuracy: 0.6815 - val_loss: 0.6121 - val_accuracy: 0.6730
    Epoch 34/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.6001 - accuracy: 0.6853 - val_loss: 0.6150 - val_accuracy: 0.6639
    Epoch 35/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5981 - accuracy: 0.6869 - val_loss: 0.6067 - val_accuracy: 0.6763
    Epoch 36/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5999 - accuracy: 0.6840 - val_loss: 0.6070 - val_accuracy: 0.6815
    Epoch 37/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5985 - accuracy: 0.6842 - val_loss: 0.6096 - val_accuracy: 0.6828
    Epoch 38/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5971 - accuracy: 0.6853 - val_loss: 0.6177 - val_accuracy: 0.6711
    Epoch 39/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5978 - accuracy: 0.6895 - val_loss: 0.6102 - val_accuracy: 0.6770
    Epoch 40/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5993 - accuracy: 0.6840 - val_loss: 0.6095 - val_accuracy: 0.6802
    Epoch 41/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5983 - accuracy: 0.6862 - val_loss: 0.6099 - val_accuracy: 0.6746
    Epoch 42/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5990 - accuracy: 0.6855 - val_loss: 0.6160 - val_accuracy: 0.6763
    Epoch 43/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5960 - accuracy: 0.6854 - val_loss: 0.6224 - val_accuracy: 0.6739
    Epoch 44/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5970 - accuracy: 0.6885 - val_loss: 0.6091 - val_accuracy: 0.6728
    Epoch 45/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5982 - accuracy: 0.6867 - val_loss: 0.6081 - val_accuracy: 0.6791
    Epoch 46/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5963 - accuracy: 0.6846 - val_loss: 0.6049 - val_accuracy: 0.6735
    Epoch 47/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5974 - accuracy: 0.6861 - val_loss: 0.6125 - val_accuracy: 0.6743
    Epoch 48/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5965 - accuracy: 0.6882 - val_loss: 0.6044 - val_accuracy: 0.6761
    Epoch 49/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5960 - accuracy: 0.6882 - val_loss: 0.6054 - val_accuracy: 0.6728
    Epoch 50/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5984 - accuracy: 0.6824 - val_loss: 0.6073 - val_accuracy: 0.6804
    Epoch 51/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5980 - accuracy: 0.6850 - val_loss: 0.6175 - val_accuracy: 0.6676
    Epoch 52/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5959 - accuracy: 0.6904 - val_loss: 0.6049 - val_accuracy: 0.6824
    Epoch 53/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5933 - accuracy: 0.6895 - val_loss: 0.6135 - val_accuracy: 0.6730
    Epoch 54/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5966 - accuracy: 0.6915 - val_loss: 0.6229 - val_accuracy: 0.6609
    Epoch 55/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5951 - accuracy: 0.6903 - val_loss: 0.6084 - val_accuracy: 0.6704
    Epoch 56/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5970 - accuracy: 0.6839 - val_loss: 0.6045 - val_accuracy: 0.6765
    Epoch 57/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5948 - accuracy: 0.6916 - val_loss: 0.6077 - val_accuracy: 0.6767
    Epoch 58/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5940 - accuracy: 0.6906 - val_loss: 0.6007 - val_accuracy: 0.6826
    Epoch 59/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5963 - accuracy: 0.6859 - val_loss: 0.6212 - val_accuracy: 0.6672
    Epoch 60/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5937 - accuracy: 0.6900 - val_loss: 0.6006 - val_accuracy: 0.6828
    Epoch 61/150
    576/576 [==============================] - 8s 14ms/step - loss: 0.5962 - accuracy: 0.6884 - val_loss: 0.6029 - val_accuracy: 0.6846
    Epoch 62/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5920 - accuracy: 0.6908 - val_loss: 0.6020 - val_accuracy: 0.6828
    Epoch 63/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5947 - accuracy: 0.6890 - val_loss: 0.6046 - val_accuracy: 0.6843
    Epoch 64/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5909 - accuracy: 0.6922 - val_loss: 0.6020 - val_accuracy: 0.6841
    Epoch 65/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5935 - accuracy: 0.6910 - val_loss: 0.6011 - val_accuracy: 0.6783
    Epoch 66/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5931 - accuracy: 0.6925 - val_loss: 0.6010 - val_accuracy: 0.6861
    Epoch 67/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5941 - accuracy: 0.6870 - val_loss: 0.6014 - val_accuracy: 0.6824
    Epoch 68/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5934 - accuracy: 0.6903 - val_loss: 0.6031 - val_accuracy: 0.6883
    Epoch 69/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5926 - accuracy: 0.6882 - val_loss: 0.6065 - val_accuracy: 0.6733
    Epoch 70/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5929 - accuracy: 0.6920 - val_loss: 0.6101 - val_accuracy: 0.6793
    Epoch 71/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5931 - accuracy: 0.6914 - val_loss: 0.6024 - val_accuracy: 0.6828
    Epoch 72/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5931 - accuracy: 0.6953 - val_loss: 0.6017 - val_accuracy: 0.6837
    Epoch 73/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5922 - accuracy: 0.6900 - val_loss: 0.5976 - val_accuracy: 0.6907
    Epoch 74/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5925 - accuracy: 0.6915 - val_loss: 0.6004 - val_accuracy: 0.6867
    Epoch 75/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5913 - accuracy: 0.6897 - val_loss: 0.5936 - val_accuracy: 0.6867
    Epoch 76/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5918 - accuracy: 0.6929 - val_loss: 0.6003 - val_accuracy: 0.6761
    Epoch 77/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5886 - accuracy: 0.6959 - val_loss: 0.6015 - val_accuracy: 0.6857
    Epoch 78/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5928 - accuracy: 0.6952 - val_loss: 0.6019 - val_accuracy: 0.6857
    Epoch 79/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5908 - accuracy: 0.6931 - val_loss: 0.5966 - val_accuracy: 0.6843
    Epoch 80/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5899 - accuracy: 0.6899 - val_loss: 0.6149 - val_accuracy: 0.6702
    Epoch 81/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5933 - accuracy: 0.6886 - val_loss: 0.5932 - val_accuracy: 0.6911
    Epoch 82/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5911 - accuracy: 0.6943 - val_loss: 0.6049 - val_accuracy: 0.6817
    Epoch 83/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5912 - accuracy: 0.6924 - val_loss: 0.6084 - val_accuracy: 0.6702
    Epoch 84/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5926 - accuracy: 0.6887 - val_loss: 0.6139 - val_accuracy: 0.6743
    Epoch 85/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5893 - accuracy: 0.6981 - val_loss: 0.6047 - val_accuracy: 0.6822
    Epoch 86/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5894 - accuracy: 0.6956 - val_loss: 0.5991 - val_accuracy: 0.6907
    Epoch 87/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5886 - accuracy: 0.6947 - val_loss: 0.5943 - val_accuracy: 0.6900
    Epoch 88/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5900 - accuracy: 0.6904 - val_loss: 0.6107 - val_accuracy: 0.6796
    Epoch 89/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5894 - accuracy: 0.6960 - val_loss: 0.6086 - val_accuracy: 0.6804
    Epoch 90/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5927 - accuracy: 0.6931 - val_loss: 0.6156 - val_accuracy: 0.6765
    Epoch 91/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5901 - accuracy: 0.6946 - val_loss: 0.5958 - val_accuracy: 0.6889
    Epoch 92/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5910 - accuracy: 0.6912 - val_loss: 0.6029 - val_accuracy: 0.6893
    Epoch 93/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5917 - accuracy: 0.6921 - val_loss: 0.5968 - val_accuracy: 0.6976
    Epoch 94/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5906 - accuracy: 0.6955 - val_loss: 0.6042 - val_accuracy: 0.6783
    Epoch 95/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5895 - accuracy: 0.6937 - val_loss: 0.6004 - val_accuracy: 0.6848
    Epoch 96/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5903 - accuracy: 0.6962 - val_loss: 0.5986 - val_accuracy: 0.6917
    Epoch 97/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5888 - accuracy: 0.6961 - val_loss: 0.6241 - val_accuracy: 0.6691
    Epoch 98/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5880 - accuracy: 0.6939 - val_loss: 0.5917 - val_accuracy: 0.6924
    Epoch 99/150
    576/576 [==============================] - 9s 15ms/step - loss: 0.5894 - accuracy: 0.6951 - val_loss: 0.5944 - val_accuracy: 0.6950
    Epoch 100/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5905 - accuracy: 0.6955 - val_loss: 0.6043 - val_accuracy: 0.6815
    Epoch 101/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5886 - accuracy: 0.6968 - val_loss: 0.5945 - val_accuracy: 0.6961
    Epoch 102/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5858 - accuracy: 0.6972 - val_loss: 0.5917 - val_accuracy: 0.6896
    Epoch 103/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5862 - accuracy: 0.6965 - val_loss: 0.6065 - val_accuracy: 0.6850
    Epoch 104/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5911 - accuracy: 0.6928 - val_loss: 0.5992 - val_accuracy: 0.6857
    Epoch 105/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5863 - accuracy: 0.6954 - val_loss: 0.5970 - val_accuracy: 0.6863
    Epoch 106/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5876 - accuracy: 0.6956 - val_loss: 0.5967 - val_accuracy: 0.6867
    Epoch 107/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5870 - accuracy: 0.6989 - val_loss: 0.6128 - val_accuracy: 0.6730
    Epoch 108/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5898 - accuracy: 0.6950 - val_loss: 0.5931 - val_accuracy: 0.6924
    Epoch 109/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5873 - accuracy: 0.6973 - val_loss: 0.5993 - val_accuracy: 0.6978
    Epoch 110/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5853 - accuracy: 0.7036 - val_loss: 0.5943 - val_accuracy: 0.6924
    Epoch 111/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5861 - accuracy: 0.6996 - val_loss: 0.5966 - val_accuracy: 0.6987
    Epoch 112/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5820 - accuracy: 0.7026 - val_loss: 0.6041 - val_accuracy: 0.6850
    Epoch 113/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5886 - accuracy: 0.6926 - val_loss: 0.5952 - val_accuracy: 0.6813
    Epoch 114/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5872 - accuracy: 0.6991 - val_loss: 0.5943 - val_accuracy: 0.6937
    Epoch 115/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5850 - accuracy: 0.6976 - val_loss: 0.5896 - val_accuracy: 0.6983
    Epoch 116/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5863 - accuracy: 0.7000 - val_loss: 0.5927 - val_accuracy: 0.6876
    Epoch 117/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5870 - accuracy: 0.6964 - val_loss: 0.5918 - val_accuracy: 0.6972
    Epoch 118/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5842 - accuracy: 0.7000 - val_loss: 0.5891 - val_accuracy: 0.6898
    Epoch 119/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5835 - accuracy: 0.7017 - val_loss: 0.5863 - val_accuracy: 0.6976
    Epoch 120/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5830 - accuracy: 0.7030 - val_loss: 0.5913 - val_accuracy: 0.6943
    Epoch 121/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5835 - accuracy: 0.6991 - val_loss: 0.5993 - val_accuracy: 0.6850
    Epoch 122/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5817 - accuracy: 0.7012 - val_loss: 0.5929 - val_accuracy: 0.6922
    Epoch 123/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5863 - accuracy: 0.6970 - val_loss: 0.6011 - val_accuracy: 0.6898
    Epoch 124/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5863 - accuracy: 0.7009 - val_loss: 0.5956 - val_accuracy: 0.6915
    Epoch 125/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5830 - accuracy: 0.6994 - val_loss: 0.6007 - val_accuracy: 0.6900
    Epoch 126/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5818 - accuracy: 0.7012 - val_loss: 0.5919 - val_accuracy: 0.6926
    Epoch 127/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5839 - accuracy: 0.7033 - val_loss: 0.5983 - val_accuracy: 0.6891
    Epoch 128/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5824 - accuracy: 0.7015 - val_loss: 0.5863 - val_accuracy: 0.6954
    Epoch 129/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5811 - accuracy: 0.7016 - val_loss: 0.5917 - val_accuracy: 0.6967
    Epoch 130/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5833 - accuracy: 0.7032 - val_loss: 0.5993 - val_accuracy: 0.6937
    Epoch 131/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5848 - accuracy: 0.6991 - val_loss: 0.5939 - val_accuracy: 0.6933
    Epoch 132/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5853 - accuracy: 0.6981 - val_loss: 0.5890 - val_accuracy: 0.6937
    Epoch 133/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5831 - accuracy: 0.7027 - val_loss: 0.6199 - val_accuracy: 0.6720
    Epoch 134/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5834 - accuracy: 0.6985 - val_loss: 0.6120 - val_accuracy: 0.6739
    Epoch 136/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5829 - accuracy: 0.7028 - val_loss: 0.5976 - val_accuracy: 0.6848
    Epoch 137/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5840 - accuracy: 0.7038 - val_loss: 0.5908 - val_accuracy: 0.6909
    Epoch 138/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5842 - accuracy: 0.7013 - val_loss: 0.5891 - val_accuracy: 0.6983
    Epoch 139/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5855 - accuracy: 0.6996 - val_loss: 0.5988 - val_accuracy: 0.6863
    Epoch 140/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5808 - accuracy: 0.7033 - val_loss: 0.5935 - val_accuracy: 0.6887
    Epoch 141/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5809 - accuracy: 0.7030 - val_loss: 0.6197 - val_accuracy: 0.6730
    Epoch 142/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5836 - accuracy: 0.7020 - val_loss: 0.5924 - val_accuracy: 0.6896
    Epoch 143/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5788 - accuracy: 0.7052 - val_loss: 0.5927 - val_accuracy: 0.6900
    Epoch 144/150
    576/576 [==============================] - 8s 13ms/step - loss: 0.5789 - accuracy: 0.7030 - val_loss: 0.6282 - val_accuracy: 0.6724
    Epoch 145/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5804 - accuracy: 0.7043 - val_loss: 0.5894 - val_accuracy: 0.6922
    Epoch 146/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5817 - accuracy: 0.7055 - val_loss: 0.5861 - val_accuracy: 0.6980
    Epoch 147/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5797 - accuracy: 0.6987 - val_loss: 0.5914 - val_accuracy: 0.7007
    Epoch 148/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5796 - accuracy: 0.7047 - val_loss: 0.5926 - val_accuracy: 0.6917
    Epoch 149/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5792 - accuracy: 0.7048 - val_loss: 0.6058 - val_accuracy: 0.6776
    Epoch 150/150
    576/576 [==============================] - 7s 13ms/step - loss: 0.5808 - accuracy: 0.7046 - val_loss: 0.5865 - val_accuracy: 0.6941


## Visualize training results

After applying data augmentation and `tf.keras.layers.Dropout`, there is less overfitting than before, and training and validation accuracy are closer aligned:


```python
acc = history.history['accuracy']
val_acc = history.history['val_accuracy']

loss = history.history['loss']
val_loss = history.history['val_loss']

epochs_range = range(epochs)

plt.figure(figsize=(8, 8))
plt.subplot(1, 2, 1)
plt.plot(epochs_range, acc, label='Training Accuracy')
plt.plot(epochs_range, val_acc, label='Validation Accuracy')
plt.legend(loc='lower right')
plt.title('Training and Validation Accuracy')

plt.subplot(1, 2, 2)
plt.plot(epochs_range, loss, label='Training Loss')
plt.plot(epochs_range, val_loss, label='Validation Loss')
plt.legend(loc='upper right')
plt.title('Training and Validation Loss')
plt.show()
```


    
![png](output_86_0.png)
    


## Predict on new data

Use your model to classify an image that wasn't included in the training or validation sets.

Note: Data augmentation and dropout layers are inactive at inference time.


```python
# import zipfile
# with zipfile.ZipFile("./test.zip", 'r') as zip_ref:
#     zip_ref.extractall("./")
```


```python
# Generate Test data 
import pathlib

test_dir = "/home/ec2-user/SageMaker/test"

print(os.listdir(test_dir))

demented = "/home/ec2-user/SageMaker/test/demented"
not_demented = "/home/ec2-user/SageMaker/test/not_demented"

print(len(os.listdir(demented)))


demented_data = os.listdir(demented)
not_demented_data = os.listdir(not_demented)

data = []
labels = []
for i in range(len(os.listdir(demented))):
    try:
        temp_file_d = demented_data[i]
        path = demented + "/" + temp_file_d
        temp = pathlib.Path(path)
        image_dem = tf.keras.utils.load_img(temp)
        data.append(image_dem)
        labels.append("demented")
#         print(image_dem)
#         print(list(zip(data, labels)))

        
        temp_file_nd = not_demented_data[i]
        path_temp = not_demented + "/" + temp_file_nd
        tempn = pathlib.Path(path_temp)
        image_ndem = tf.keras.utils.load_img(tempn)
        data.append(image_ndem)
        labels.append("not_demented")
    except Exception as err:
        print(i, err)
        continue
print(len(data), len(labels))

```

    ['not_demented', '.DS_Store', 'demented']
    1278
    543 cannot identify image file <_io.BytesIO object at 0x7fa992a50f90>
    583 cannot identify image file <_io.BytesIO object at 0x7fa992ab9df0>
    2553 2553



```python
previous_img = tf.expand_dims(data[0], 0) # Create a batch

for i in range(1, 2553):
    current_img = tf.expand_dims(data[i], 0) # Create a batch
    previous_img = np.concatenate((current_img, previous_img), axis=0)

# print(previous_img.shape)
f, s, t, fo = previous_img.shape
print(np.max(previous_img))
previous_img = previous_img/255
print(np.max(previous_img))

# print(prev_img.shape)


lab = []
for each in labels:
    if each == "demented":
        lab.append(0)
    elif each == "not_demented":
        lab.append(1)
lab = lab
print(len(lab))
```

    255
    1.0
    2553



```python
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report

class_names = ["not_demented", "demented"]

lab = []
for each in labels:
    if each == "demented":
        lab.append(0)
    elif each == "not_demented":
        lab.append(1)
# print(len(lab))


predictions = model.predict(previous_img)
score = tf.nn.softmax(predictions)
class_index = [np.argmax(x) for x in score]

class_name = [class_names[index] for index in class_index]


y_pred = class_index
y_test = lab



confusion_matrix = tf.math.confusion_matrix(predictions = y_pred, labels = y_test)
print(confusion_matrix)

```

    80/80 [==============================] - 0s 4ms/step
    tf.Tensor(
    [[   0 1277]
     [   0 1276]], shape=(2, 2), dtype=int32)



```python
ind = 2500
print(y_test[ind], y_pred[ind])


# y_pred[0:2] == y_test[0:2]
```

    1 1


## Use TensorFlow Lite

TensorFlow Lite is a set of tools that enables on-device machine learning by helping developers run their models on mobile, embedded, and edge devices.

### Convert the Keras Sequential model to a TensorFlow Lite model

To use the trained model with on-device applications, first [convert it](https://www.tensorflow.org/lite/models/convert) to a smaller and more efficient model format called a [TensorFlow Lite](https://www.tensorflow.org/lite/) model.

In this example, take the trained Keras Sequential model and use `tf.lite.TFLiteConverter.from_keras_model` to generate a [TensorFlow Lite](https://www.tensorflow.org/lite/) model:


```python
# Convert the model.
converter = tf.lite.TFLiteConverter.from_keras_model(model)
tflite_model = converter.convert()

# Save the model.
with open('model.tflite', 'wb') as f:
  f.write(tflite_model)
```

    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting RngReadAndSkip cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting Bitcast cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting StatelessRandomUniformV2 cause there is no registered converter for this op.
    WARNING:tensorflow:Using a while_loop for converting ImageProjectiveTransformV3 cause there is no registered converter for this op.


    WARNING:absl:Found untraced functions such as _jit_compiled_convolution_op, _jit_compiled_convolution_op, _jit_compiled_convolution_op while saving (showing 3 of 3). These functions will not be directly callable after loading.


    INFO:tensorflow:Assets written to: /tmpfs/tmp/tmpr2jwfqh7/assets


    INFO:tensorflow:Assets written to: /tmpfs/tmp/tmpr2jwfqh7/assets
    2022-12-14 02:30:14.950940: W tensorflow/compiler/mlir/lite/python/tf_tfl_flatbuffer_helpers.cc:362] Ignored output_format.
    2022-12-14 02:30:14.950996: W tensorflow/compiler/mlir/lite/python/tf_tfl_flatbuffer_helpers.cc:365] Ignored drop_control_dependency.


The TensorFlow Lite model you saved in the previous step can contain several function signatures. The Keras model converter API uses the default signature automatically. Learn more about [TensorFlow Lite signatures](https://www.tensorflow.org/lite/guide/signatures).

### Run the TensorFlow Lite model

You can access the TensorFlow Lite saved model signatures in Python via the `tf.lite.Interpreter` class.

Load the model with the `Interpreter`:


```python
TF_MODEL_FILE_PATH = 'model.tflite' # The default path to the saved TensorFlow Lite model

interpreter = tf.lite.Interpreter(model_path=TF_MODEL_FILE_PATH)
```

Print the signatures from the converted model to obtain the names of the inputs (and outputs):



```python
interpreter.get_signature_list()
```




    {'serving_default': {'inputs': ['sequential_1_input'], 'outputs': ['outputs']}}



In this example, you have one default signature called `serving_default`. In addition, the name of the `'inputs'` is `'sequential_1_input'`, while the `'outputs'` are called `'outputs'`. You can look up these first and last Keras layer names when running `Model.summary`, as demonstrated earlier in this tutorial.

Now you can test the loaded TensorFlow Model by performing inference on a sample image with `tf.lite.Interpreter.get_signature_runner` by passing the signature name as follows:


```python
classify_lite = interpreter.get_signature_runner('serving_default')
classify_lite
```




    <tensorflow.lite.python.interpreter.SignatureRunner at 0x7f0364433580>



Similar to what you did earlier in the tutorial, you can use the TensorFlow Lite model to classify images that weren't included in the training or validation sets.

You have already tensorized that image and saved it as `img_array`. Now, pass it to the first argument (the name of the `'inputs'`) of the loaded TensorFlow Lite model (`predictions_lite`), compute softmax activations, and then print the prediction for the class with the highest computed probability.


```python
predictions_lite = classify_lite(sequential_1_input=img_array)['outputs']
score_lite = tf.nn.softmax(predictions_lite)
```


```python
print(
    "This image most likely belongs to {} with a {:.2f} percent confidence."
    .format(class_names[np.argmax(score_lite)], 100 * np.max(score_lite))
)
```

    This image most likely belongs to sunflowers with a 97.33 percent confidence.


The prediction generated by the lite model should be almost identical to the predictions generated by the original model:


```python
print(np.max(np.abs(predictions - predictions_lite)))
```

    1.4305115e-06


Of the five classes—`'daisy'`, `'dandelion'`, `'roses'`, `'sunflowers'`, and `'tulips'`—the model should predict the image belongs to sunflowers, which is the same result as before the TensorFlow Lite conversion.


## Next steps

This tutorial showed how to train a model for image classification, test it, convert it to the TensorFlow Lite format for on-device applications (such as an image classification app), and perform inference with the TensorFlow Lite model with the Python API.

You can learn more about TensorFlow Lite through [tutorials](https://www.tensorflow.org/lite/tutorials) and [guides](https://www.tensorflow.org/lite/guide).
